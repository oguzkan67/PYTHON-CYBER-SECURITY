/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Search, AlertTriangle, CheckCircle, Info, Lock, Globe, Terminal, Activity, FileText, Download, ChevronDown, ChevronUp, Bug } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';
import { WolfLogo } from './components/WolfLogo';
import { MatrixRain } from './components/MatrixRain';

function cn(...inputs: (string | undefined | null | false)[]) {
  return twMerge(clsx(inputs));
}

interface VulnerabilityReport {
  type: string;
  severity: 'Critical' | 'High' | 'Medium' | 'Low' | 'Info';
  description: string;
  recommendation: string;
  location: string;
  payload?: string;
  evidence?: string;
  exploitationSteps?: string;
}

interface ScanResult {
  target: string;
  timestamp: string;
  score: number;
  crawledUrls: string[];
  vulnerabilities: VulnerabilityReport[];
  headers: Record<string, string>;
}

export default function App() {
  const [url, setUrl] = useState('');
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [expandedVuln, setExpandedVuln] = useState<number | null>(null);
  const [progress, setProgress] = useState<{ message: string; current?: number; total?: number } | null>(null);
  const abortControllerRef = React.useRef<AbortController | null>(null);
  const eventSourceRef = React.useRef<EventSource | null>(null);

  const handleScan = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!url) return;

    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
    }

    const controller = new AbortController();
    abortControllerRef.current = controller;

    setIsScanning(true);
    setError(null);
    setResult(null);
    setProgress({ message: 'Initializing scan...' });

    // Start SSE for progress
    const eventSource = new EventSource('/api/scan-progress');
    eventSourceRef.current = eventSource;

    eventSource.onmessage = (event) => {
      const data = JSON.parse(event.data);
      if (data.type === 'status' || data.type === 'progress') {
        setProgress(data);
      } else if (data.type === 'complete') {
        eventSource.close();
        setProgress(null);
      }
    };

    try {
      const response = await fetch('/api/scan', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url }),
        signal: controller.signal
      });

      if (!response.ok) {
        const errData = await response.json();
        throw new Error(errData.error || 'Failed to scan URL');
      }

      const data = await response.json();
      setResult(data);
    } catch (err: any) {
      if (err.name === 'AbortError') {
        setError('Scan cancelled by user.');
      } else {
        setError(err.message || 'Failed to connect to the target. Please check the URL and try again.');
      }
    } finally {
      setIsScanning(false);
      abortControllerRef.current = null;
      if (eventSourceRef.current) {
        eventSourceRef.current.close();
        eventSourceRef.current = null;
      }
      setProgress(null);
    }
  };

  const handleCancel = () => {
    if (abortControllerRef.current) {
      abortControllerRef.current.abort();
    }
    if (eventSourceRef.current) {
      eventSourceRef.current.close();
      eventSourceRef.current = null;
    }
    setProgress(null);
  };

  const downloadReport = () => {
    if (!result) return;

    const lines = [
      "CyberKAY Security Report",
      "========================",
      `Target: ${result.target}`,
      `Date: ${new Date(result.timestamp).toLocaleString()}`,
      `Score: ${result.score}/100`,
      "",
      "Summary",
      "-------",
      `Total Vulnerabilities: ${result.vulnerabilities.length}`,
      `Pages Crawled: ${result.crawledUrls.length}`,
      "",
      "Vulnerabilities",
      "---------------"
    ];

    result.vulnerabilities.forEach((v, i) => {
      lines.push(`[${i + 1}] ${v.type} (${v.severity})`);
      lines.push(`Location: ${v.location}`);
      if (v.payload) lines.push(`Payload: ${v.payload}`);
      lines.push(`Description: ${v.description}`);
      lines.push(`Recommendation: ${v.recommendation}`);
      if (v.evidence) lines.push(`Evidence: ${v.evidence.substring(0, 100)}...`);
      if (v.exploitationSteps) {
        lines.push("");
        lines.push("Exploitation Scenario:");
        lines.push(v.exploitationSteps);
      }
      lines.push("");
      lines.push("--------------------------------------------------");
      lines.push("");
    });

    lines.push("Crawled URLs");
    lines.push("------------");
    result.crawledUrls.forEach(u => lines.push(u));

    const blob = new Blob([lines.join("\n")], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cyberkay_report_${new Date().getTime()}.txt`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'text-purple-500 border-purple-500/20 bg-purple-500/10';
      case 'High': return 'text-red-500 border-red-500/20 bg-red-500/10';
      case 'Medium': return 'text-orange-500 border-orange-500/20 bg-orange-500/10';
      case 'Low': return 'text-yellow-500 border-yellow-500/20 bg-yellow-500/10';
      default: return 'text-blue-500 border-blue-500/20 bg-blue-500/10';
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500';
    if (score >= 70) return 'text-yellow-500';
    if (score >= 50) return 'text-orange-500';
    return 'text-red-500';
  };

  return (
    <div className="min-h-screen bg-black text-green-500 font-mono selection:bg-green-500/30 selection:text-green-100 relative overflow-hidden">
      <MatrixRain isActive={isScanning} />
      
      {/* Background Grid Effect */}
      <div className="fixed inset-0 pointer-events-none opacity-10" 
           style={{ 
             backgroundImage: 'linear-gradient(rgba(0, 255, 0, 0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(0, 255, 0, 0.1) 1px, transparent 1px)',
             backgroundSize: '20px 20px'
           }} 
      />

      <div className="relative max-w-6xl mx-auto p-6 z-10">
        {/* Header */}
        <header className="flex items-center justify-between mb-12 border-b border-green-500/30 pb-6">
          <div className="flex items-center gap-3">
            <div className="p-2 border border-green-500 rounded bg-green-500/10 shadow-[0_0_15px_rgba(0,255,0,0.3)]">
              <WolfLogo className="w-8 h-8" isScanning={isScanning} />
            </div>
            <div>
              <h1 className="text-3xl font-bold tracking-tighter">CyberKAY <span className="text-sm font-normal opacity-50 ml-2">v2.0</span></h1>
              <p className="text-xs text-green-500/60 uppercase tracking-widest">Advanced Penetration Testing Suite</p>
            </div>
          </div>
          <div className="flex items-center gap-4">
             <div className="flex items-center gap-2 text-xs text-green-500/60 px-3 py-1 border border-green-500/20 rounded-full">
                <Bug className="w-3 h-3" />
                <span>SQLi MODULE: ACTIVE</span>
             </div>
             <div className="flex items-center gap-2 text-xs text-green-500/60">
                <Activity className="w-4 h-4 animate-pulse" />
                <span>SYSTEM ONLINE</span>
             </div>
          </div>
        </header>

        {/* Search Input */}
        <div className="mb-12">
          <form onSubmit={handleScan} className="relative group max-w-3xl mx-auto">
            <div className="absolute inset-0 bg-green-500/20 blur-xl group-hover:bg-green-500/30 transition-all duration-500 rounded-lg" />
            <div className="relative flex items-center bg-black border border-green-500/50 rounded-lg overflow-hidden shadow-[0_0_15px_rgba(0,255,0,0.1)]">
              <div className="pl-4 text-green-500/50">
                <Globe className="w-5 h-5" />
              </div>
              <input
                type="text"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="ENTER TARGET URL (e.g., testphp.vulnweb.com)"
                className="w-full bg-transparent border-none py-4 px-4 text-green-500 placeholder-green-500/30 focus:ring-0 focus:outline-none font-mono text-lg"
              />
              <button
                type="submit"
                disabled={isScanning}
                className="px-8 py-4 bg-green-500/10 hover:bg-green-500/20 text-green-500 font-bold border-l border-green-500/30 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center gap-2 whitespace-nowrap"
              >
                {isScanning ? (
                  <>
                    <Activity className="w-4 h-4 animate-spin" />
                    SCANNING...
                  </>
                ) : (
                  <>
                    <Search className="w-4 h-4" />
                    FULL SCAN
                  </>
                )}
              </button>
              {isScanning && (
                <button
                  type="button"
                  onClick={handleCancel}
                  className="px-6 py-4 bg-red-500/10 hover:bg-red-500/20 text-red-500 font-bold border-l border-red-500/30 transition-colors flex items-center gap-2 whitespace-nowrap"
                >
                  CANCEL
                </button>
              )}
            </div>
            {progress && (
              <div className="mt-4 max-w-3xl mx-auto">
                <div className="flex justify-between text-xs text-green-500/70 mb-1 font-mono">
                  <span>{progress.message}</span>
                  {progress.current && progress.total && (
                    <span>{Math.round((progress.current / progress.total) * 100)}%</span>
                  )}
                </div>
                {progress.current && progress.total && (
                  <div className="h-1 bg-green-900/30 rounded-full overflow-hidden">
                    <motion.div 
                      className="h-full bg-green-500 shadow-[0_0_10px_rgba(74,222,128,0.5)]"
                      initial={{ width: 0 }}
                      animate={{ width: `${(progress.current / progress.total) * 100}%` }}
                      transition={{ duration: 0.3 }}
                    />
                  </div>
                )}
              </div>
            )}
            <p className="mt-4 text-center text-xs text-green-500/40 flex items-center justify-center gap-1">
              <AlertTriangle className="w-3 h-3" />
              WARNING: ACTIVE SCANNING WILL SEND ATTACK PAYLOADS. USE ONLY ON AUTHORIZED TARGETS.
            </p>
          </form>
        </div>

        {/* Error Message */}
        {error && (
          <motion.div
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="p-4 border border-red-500/50 bg-red-500/10 text-red-500 rounded-lg mb-8 flex items-center gap-3 max-w-3xl mx-auto"
          >
            <AlertTriangle className="w-5 h-5" />
            {error}
          </motion.div>
        )}

        {/* Results */}
        <AnimatePresence>
          {result && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 20 }}
              className="space-y-8"
            >
              {/* Text Summary */}
              <div className="p-6 border border-green-500/30 bg-green-500/10 rounded-lg backdrop-blur-sm">
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-green-500/20 rounded-full">
                    <CheckCircle className="w-6 h-6 text-green-400" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-white mb-2">Scan Completed Successfully</h3>
                    <p className="text-green-400/80 mb-4 font-mono">
                      Target: <span className="text-white font-bold">{result.target}</span>
                    </p>
                    <div className="flex flex-wrap gap-3 text-sm font-bold">
                      <span className="px-3 py-1 rounded bg-purple-500/20 text-purple-400 border border-purple-500/30">
                        {result.vulnerabilities.filter(v => v.severity === 'Critical').length} CRITICAL
                      </span>
                      <span className="px-3 py-1 rounded bg-red-500/20 text-red-400 border border-red-500/30">
                        {result.vulnerabilities.filter(v => v.severity === 'High').length} HIGH
                      </span>
                      <span className="px-3 py-1 rounded bg-orange-500/20 text-orange-400 border border-orange-500/30">
                        {result.vulnerabilities.filter(v => v.severity === 'Medium').length} MEDIUM
                      </span>
                      <span className="px-3 py-1 rounded bg-yellow-500/20 text-yellow-400 border border-yellow-500/30">
                        {result.vulnerabilities.filter(v => v.severity === 'Low').length} LOW
                      </span>
                      <span className="px-3 py-1 rounded bg-blue-500/20 text-blue-400 border border-blue-500/30">
                        {result.vulnerabilities.filter(v => v.severity === 'Info').length} INFO
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Score Card */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                <div className="md:col-span-1 p-6 border border-green-500/30 bg-green-500/5 rounded-lg flex flex-col items-center justify-center text-center relative overflow-hidden">
                  <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-green-500/10 via-transparent to-transparent opacity-50" />
                  <h3 className="text-sm uppercase tracking-widest text-green-500/60 mb-2">Security Score</h3>
                  <div className={cn("text-6xl font-bold mb-2", getScoreColor(result.score))}>
                    {result.score}
                  </div>
                  <div className="text-xs text-green-500/40">OUT OF 100</div>
                </div>

                <div className="md:col-span-3 p-6 border border-green-500/30 bg-green-500/5 rounded-lg relative">
                  <button 
                    onClick={downloadReport}
                    className="absolute top-4 right-4 p-2 hover:bg-green-500/20 rounded transition-colors text-green-500/80"
                    title="Download Report"
                  >
                    <Download className="w-5 h-5" />
                  </button>

                  <h3 className="text-sm uppercase tracking-widest text-green-500/60 mb-4 flex items-center gap-2">
                    <Terminal className="w-4 h-4" />
                    Scan Summary
                  </h3>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div className="space-y-1 col-span-2">
                      <div className="text-green-500/40">TARGET</div>
                      <div className="truncate font-bold" title={result.target}>{result.target}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-green-500/40">TIMESTAMP</div>
                      <div>{new Date(result.timestamp).toLocaleTimeString()}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-green-500/40">PAGES CRAWLED</div>
                      <div>{result.crawledUrls.length}</div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-green-500/40">VULNERABILITIES</div>
                      <div className={result.vulnerabilities.length > 0 ? 'text-red-500 font-bold' : 'text-green-500'}>
                        {result.vulnerabilities.length}
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-green-500/40">CRITICAL ISSUES</div>
                      <div className="text-purple-500 font-bold">
                        {result.vulnerabilities.filter(v => v.severity === 'Critical').length}
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Vulnerabilities List */}
              <div className="space-y-4">
                <h3 className="text-xl font-bold flex items-center gap-2 border-b border-green-500/30 pb-2">
                  <Bug className="w-5 h-5" />
                  Detected Vulnerabilities
                </h3>
                
                {result.vulnerabilities.length === 0 ? (
                  <div className="p-8 border border-green-500/30 bg-green-500/5 rounded-lg text-center text-green-500/60">
                    <CheckCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>No vulnerabilities detected.</p>
                  </div>
                ) : (
                  result.vulnerabilities.map((vuln, index) => (
                    <motion.div
                      key={index}
                      initial={{ opacity: 0, x: -20 }}
                      animate={{ opacity: 1, x: 0 }}
                      transition={{ delay: index * 0.1 }}
                      className={cn("border rounded-lg relative overflow-hidden transition-all", getSeverityColor(vuln.severity))}
                    >
                      <div 
                        className="p-6 cursor-pointer flex items-start justify-between"
                        onClick={() => setExpandedVuln(expandedVuln === index ? null : index)}
                      >
                        <div className="flex-1">
                          <div className="flex items-center gap-3 mb-2">
                            <span className={cn("px-2 py-0.5 rounded text-xs font-bold uppercase border", getSeverityColor(vuln.severity))}>
                              {vuln.severity}
                            </span>
                            <h4 className="font-bold text-lg">{vuln.type}</h4>
                          </div>
                          <p className="text-sm opacity-80 truncate max-w-2xl">{vuln.description}</p>
                        </div>
                        <div className="ml-4">
                          {expandedVuln === index ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
                        </div>
                      </div>

                      <AnimatePresence>
                        {expandedVuln === index && (
                          <motion.div
                            initial={{ height: 0, opacity: 0 }}
                            animate={{ height: 'auto', opacity: 1 }}
                            exit={{ height: 0, opacity: 0 }}
                            className="border-t border-current border-opacity-10 bg-black/20"
                          >
                            <div className="p-6 grid gap-4 text-sm">
                              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                  <span className="block text-xs uppercase opacity-50 mb-1">Location</span>
                                  <div className="font-mono text-xs break-all bg-black/40 p-2 rounded border border-white/10">
                                    {vuln.location}
                                  </div>
                                </div>
                                {vuln.payload && (
                                  <div>
                                    <span className="block text-xs uppercase opacity-50 mb-1">Payload Used</span>
                                    <div className="font-mono text-xs break-all bg-black/40 p-2 rounded border border-white/10 text-red-400">
                                      {vuln.payload}
                                    </div>
                                  </div>
                                )}
                              </div>

                              <div>
                                <span className="block text-xs uppercase opacity-50 mb-1">Description</span>
                                <p className="opacity-90">{vuln.description}</p>
                              </div>

                              <div>
                                <span className="block text-xs uppercase opacity-50 mb-1">Recommendation</span>
                                <p className="opacity-90">{vuln.recommendation}</p>
                              </div>

                              {vuln.evidence && (
                                <div>
                                  <span className="block text-xs uppercase opacity-50 mb-1">Evidence (Response Snippet)</span>
                                  <pre className="font-mono text-xs bg-black/40 p-2 rounded border border-white/10 overflow-x-auto text-yellow-500/80">
                                    {vuln.evidence}
                                  </pre>
                                </div>
                              )}

                              {vuln.exploitationSteps && (
                                <div className="mt-2 pt-4 border-t border-white/10">
                                  <span className="block text-xs uppercase opacity-50 mb-2 text-red-400">Hacker's Perspective: Exploitation Steps</span>
                                  <div className="text-xs opacity-90 whitespace-pre-wrap font-mono bg-red-500/5 p-4 rounded border border-red-500/20">
                                    {vuln.exploitationSteps}
                                  </div>
                                </div>
                              )}
                            </div>
                          </motion.div>
                        )}
                      </AnimatePresence>
                    </motion.div>
                  ))
                )}
              </div>

              {/* Crawled URLs */}
              <div className="border border-green-500/30 rounded-lg overflow-hidden">
                <div className="bg-green-500/10 p-4 border-b border-green-500/30">
                  <h3 className="font-bold flex items-center gap-2">
                    <Globe className="w-4 h-4" />
                    Crawled Pages ({result.crawledUrls.length})
                  </h3>
                </div>
                <div className="p-4 bg-black font-mono text-xs overflow-x-auto max-h-40 overflow-y-auto">
                  <ul className="space-y-1 text-green-500/70">
                    {result.crawledUrls.map((u, i) => (
                      <li key={i}>{u}</li>
                    ))}
                  </ul>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
}

