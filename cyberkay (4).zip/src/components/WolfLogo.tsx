import React from 'react';
import { motion } from 'motion/react';

export const WolfLogo = ({ className, isScanning = false }: { className?: string; isScanning?: boolean }) => (
  <motion.svg
    xmlns="http://www.w3.org/2000/svg"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="1.5"
    strokeLinecap="round"
    strokeLinejoin="round"
    className={className}
    animate={isScanning ? {
      stroke: "#4ade80", // brighter green (green-400)
      scale: [1, 1.1, 1],
      filter: ["drop-shadow(0 0 0px rgba(74, 222, 128, 0))", "drop-shadow(0 0 8px rgba(74, 222, 128, 0.5))", "drop-shadow(0 0 0px rgba(74, 222, 128, 0))"]
    } : {
      stroke: "currentColor",
      scale: 1,
      filter: "drop-shadow(0 0 0px rgba(0,0,0,0))"
    }}
    transition={{
      duration: 2,
      repeat: isScanning ? Infinity : 0,
      ease: "easeInOut"
    }}
  >
    {/* Geometric Wolf Head */}
    <path d="M12 2L5 9l3 5-3 6 7 2 7-2-3-6 3-5-7-7z" />
    <path d="M12 2v11" />
    <path d="M8 14l4 2 4-2" />
    <path d="M8 9l4 2 4-2" />
    <circle cx="9" cy="7" r="0.5" fill="currentColor" />
    <circle cx="15" cy="7" r="0.5" fill="currentColor" />
  </motion.svg>
);
